
# MYQER Front-end Hooks for Backend

Add these tiny hooks to wire your dashboard to the new Edge Functions.

## 1) Include the script

In `public/app.html`, after your existing scripts, add:

```html
<script type="module" src="/scripts/backend_hooks.js"></script>
```

Also expose the Supabase URL for the hooks to call (they reuse the JWT stored by your app):

```html
<meta name="supabase-url" content="https://YOUR-PROJECT-REF.supabase.co">
```

## 2) Add buttons/areas (suggested)

Somewhere in your QR section:

```html
<div class="card section">
  <h2>Backend Actions</h2>
  <div id="voiceWrap"></div>
  <div style="display:flex; gap:.5rem; flex-wrap:wrap">
    <button id="btnRegenQR" class="pill red">Regenerate QR</button>
    <button id="btnBuildVoice" class="pill">Build Voice (TTS)</button>
    <button id="btnPreviewResponder" class="pill">Preview Responder JSON</button>
  </div>
  <pre id="previewOut" class="glass" style="min-height:120px; padding:12px; border-radius:12px; overflow:auto"></pre>
</div>
```

## 3) Auto-build voice after health save

From your `scripts/app.js`, dispatch a custom event right after saving health:

```js
// after successful save to health_profiles
window.dispatchEvent(new Event('myqer:healthSaved'));
```

The hooks listen for this event and call the `myqer-tts-build` function (debounced).

## 4) CORS

Ensure your Supabase project allows your domain in Auth settings (Site URL & Redirects).

## 5) Troubleshooting
- If requests fail with 401, make sure the user is logged in and `myqer_jwt` exists in localStorage.
- If you see CORS errors, check project URL and domain settings.
- Public card preview is rate-limited; don’t mash the button.
