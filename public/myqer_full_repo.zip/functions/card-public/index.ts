// card-public Edge Function (placeholder)
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

serve((req) => new Response(JSON.stringify({"function":"card-public","ok":true}), {"headers":{"content-type":"application/json"}}));
