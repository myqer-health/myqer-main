
# MYQER Backend (Supabase)

This repository contains the production-ready backend per the **MASTER BACKEND BUILD BRIEF — MYQER**.

## Contents
- `schema.sql` — Postgres schema, triggers, RLS, indexes
- `storage.sql` — Buckets (`qr`, `voices`) and storage policies
- `functions/` — Supabase Edge Functions (Deno):
  - `myqer-qr-generate`
  - `myqer-card-public`
  - `myqer-card-dispatch`
  - `myqer-tts-build`
  - `myqer-offline-card`
- `locales/server-phrases/{en,es,fr,de,it,pt,ro,ar,hi,zh}.json`

## Prerequisites
- Supabase project
- Supabase CLI: `npm i -g supabase`
- Configure Auth emails (Confirm + Reset) and redirect URLs to your domain.
- Create service role key and anon key (Project Settings → API).

## Setup

```bash
# 1) Clone and open project
# git clone <repo> && cd myqer-backend

# 2) Apply database schema
supabase db push --file schema.sql

# 3) Configure storage buckets & policies
supabase db push --file storage.sql

# 4) Upload server phrase packs (optional: keep in repo & host via Functions static)
supabase storage cp -b public -p locales/server-phrases ./locales/server-phrases
# Or just ensure your hosting serves /locales/server-phrases/*
```

### Deploy Edge Functions

Set function secrets:
```bash
supabase functions secrets set \
  SUPABASE_URL=https://YOUR-PROJECT-REF.supabase.co \
  SUPABASE_ANON_KEY=YOUR-ANON-KEY \
  SUPABASE_SERVICE_ROLE_KEY=YOUR-SERVICE-ROLE-KEY \
  APP_ORIGIN=https://myqer.com \
  TTS_PROVIDER=azure \
  TTS_API_KEY=YOUR_TTS_KEY \
  TTS_REGION=westeurope
```

Deploy:
```bash
supabase functions deploy myqer-qr-generate
supabase functions deploy myqer-card-public
supabase functions deploy myqer-card-dispatch
supabase functions deploy myqer-tts-build
supabase functions deploy myqer-offline-card
```

### Test (curl examples)

```bash
# QR generate (requires user JWT)
curl -X POST -H "Authorization: Bearer <USER_JWT>" \
  https://<PROJECT>.supabase.co/functions/v1/myqer-qr-generate

# Public card (rate limited)
curl "https://<PROJECT>.supabase.co/functions/v1/myqer-card-public?code=ABCDEFG&lang=es"

# Dispatch (org user header)
curl -H "x-org-user: <CLINICIAN_USER_ID>" \
 "https://<PROJECT>.supabase.co/functions/v1/myqer-card-dispatch?code=ABCDEFG&org=<ORG_ID>&lang=en"

# TTS build
curl -X POST -H "Authorization: Bearer <USER_JWT>" -H "Content-Type: application/json" \
  -d '{"lang":"es"}' \
  https://<PROJECT>.supabase.co/functions/v1/myqer-tts-build

# Offline card (for PWA caching)
curl -H "Authorization: Bearer <USER_JWT>" \
  https://<PROJECT>.supabase.co/functions/v1/myqer-offline-card
```

## Front-end hooks
- **Regenerate QR** → call `myqer-qr-generate` (POST), show `url` + `svg_url`
- **Responder Preview** → fetch `myqer-card-public?code=...`
- **Build Voice** → call `myqer-tts-build` after saving health; play result with signed URL
- **Offline Cache** → hit `myqer-offline-card` and store response

## Security notes
- All buckets are private; clients only receive **signed URLs**.
- `access_logs` inserts require service role (Edge Functions).
- Rate limiting is in-memory per instance; for global limits, add KV/Redis later.
- CORS: set allowed origin to your domain in Supabase Dashboard → Auth → URL configs.

## Acceptance Checklist
- User registers, confirms email, logs in.
- Profile + Health saved with RLS enforced.
- QR generated; responder card returns **consented** fields only.
- Language param returns localized labels and voice signed URL.
- Rate limit kicks in at >5 requests per minute per IP on public card.
- Org member can call `card-dispatch` and receives extended TTL.

---

UK-English copy by default.
